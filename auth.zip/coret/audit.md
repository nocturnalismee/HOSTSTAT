# Analisis Mendalam & PRD: ServMon — Server Monitoring Website

---

## Bagian 1 — Analisis Komprehensif Codebase Saat Ini

### 1.1 Ringkasan Arsitektur

ServMon adalah aplikasi **self-hosted server monitoring** berbasis **PHP 8.2+ / MySQL 8.0** dengan arsitektur **push-based** dan rendering **server-side (SSR)**.

```mermaid
graph LR
    subgraph "Monitored Servers"
        A1[agent.sh] --> |HTTP POST + Token| B
        A2[agent-cpanel-mail.sh] --> |HTTP POST + Token| B
    end
    subgraph "ServMon Master"
        B["api/push.php"] --> C[(MySQL 8.0)]
        B --> D["Redis Cache"]
        E["workers/alert-check.php"] --> C
        F["workers/ping-check.php"] --> C
        G["workers/cleanup.php"] --> C
        H["admin/*.php"] --> C
        I["index.php - Public"] --> C
        J["api/status.php"] --> C
        E --> K["Notifications"]
        K --> K1["Email SMTP"]
        K --> K2["Telegram Bot"]
    end
    subgraph "End Users"
        L[Admin Browser] --> H
        M[Public Viewer] --> I
    end
```

| Aspek             | Detail                                                    |
| ----------------- | --------------------------------------------------------- |
| **Backend**       | PHP 8.2+, PDO/MySQL, custom SMTP socket, cURL             |
| **Database**      | MySQL 8.0, InnoDB, 14+ tabel                              |
| **Caching**       | Redis (opsional), in-memory PHP static vars               |
| **Frontend**      | Vanilla HTML/CSS/JS, Bootstrap grid system                |
| **Agent**         | Bash script (agent.sh), PHP agent stub                    |
| **Workers**       | 3 cron-based PHP scripts                                  |
| **Auth**          | Session-based, bcrypt password, role-based (admin/viewer) |
| **Notifications** | Email (native mail + custom SMTP), Telegram Bot API       |

---

### 1.2 Breakdown Modul & File

| Direktori                                                 | Jumlah File       | Fungsi Utama                                                                       |
| --------------------------------------------------------- | ----------------- | ---------------------------------------------------------------------------------- |
| `admin/`                                                  | 14 PHP            | Dashboard, Server CRUD, Alert/Audit Logs, Settings, Ping Monitors, Export          |
| `agents/`                                                 | 5 files + systemd | Bash push agent, cPanel mail agent, PHP agent stub                                 |
| [api/](file:///d:/SERVER/includes/rate_limiter.php#20-73) | 5 PHP             | Push endpoint, Status/History API, Alert API, Health check                         |
| `assets/`                                                 | 11 (1 CSS, 10 JS) | Design system, theme toggle, dashboard/detail/ping interactivity                   |
| `auth/`                                                   | 2 PHP             | Login / Logout                                                                     |
| `includes/`                                               | 17 PHP + 4 layout | Config, DB, Auth, Cache, Alerts, Settings, CSRF, Helpers, Ping, Rate Limiter, etc. |
| [sql/](file:///d:/SERVER/sql/seed.sql)                    | 2 + 13 migrations | Schema, Seed, Incremental migrations                                               |
| `tests/`                                                  | 7 files           | Smoke tests, Schema consistency, API smoke, AuthZ matrix, E2E scenarios            |
| `workers/`                                                | 3 PHP + 1 helper  | Alert check, Ping check, Cleanup/Retention                                         |

**Total: ~86 files, ~15.000 baris kode**

---

### 1.3 Analisis Per Komponen

#### Data Ingestion ([api/push.php](file:///d:/SERVER/api/push.php) — 488 baris)

| Fitur                    | Status       | Catatan                                                                          |
| ------------------------ | ------------ | -------------------------------------------------------------------------------- |
| Token auth (64-char hex) | Solid        | Regex validation                                                                 |
| HMAC request signing     | Baik         | SHA-256, timestamp window 5 menit                                                |
| IP allowlist per server  | Baik         | CIDR support                                                                     |
| Service status tracking  | Komprehensif | Panel-aware service registry, state transitions                                  |
| Panel profile detection  | Lengkap      | cPanel, Plesk, DirectAdmin, CyberPanel, aaPanel, Generic                         |
| Schema backward compat   | Defensif     | [db_column_exists()](file:///d:/SERVER/api/push.php#31-53) checks sebelum INSERT |
| Mail queue ingestion     | Multi-MTA    | Postfix, Exim, Qmail                                                             |

> [!TIP]
> **Kekuatan**: Defensif terhadap schema mismatch, backward compatible, multiple MTA support.

> [!WARNING]
> **Kelemahan**: File monolitik 488 baris tanpa class; banyak [db_column_exists()](file:///d:/SERVER/api/push.php#31-53) runtime check yang menambah query overhead; tidak ada request validation library (manual sepenuhnya).

#### Status & History API ([api/status.php](file:///d:/SERVER/api/status.php) — 247 baris)

| Fitur                            | Status | Catatan                               |
| -------------------------------- | ------ | ------------------------------------- |
| Server list + single detail      | OK     | Optimized JOIN via `latest_metric_id` |
| History aggregation (24h/7d/30d) | OK     | 5-min & 15-min bucketing              |
| Data point limiting              | OK     | Configurable 100-5000 points          |
| Redis caching                    | OK     | TTL per endpoint type                 |
| Rate limiting                    | OK     | File-based sliding window             |

> [!WARNING]
> **Kelemahan**: History SQL sangat kompleks — UNION ALL antara `metrics` dan `metrics_history` dengan nested subqueries; 7d/30d queries bisa sangat berat di database besar; tidak ada streaming/pagination untuk dataset besar.

#### Alert System ([includes/alerts.php](file:///d:/SERVER/includes/alerts.php) — 568 baris)

| Fitur                                         | Status                    |
| --------------------------------------------- | ------------------------- |
| Server down / recovery detection              | OK                        |
| Threshold alerts (CPU, RAM, Disk, Mail Queue) | Warning + Critical levels |
| Service transition alerts (up-down, down-up)  | OK                        |
| Ping monitor alerts (ICMP + HTTP)             | OK                        |
| Cooldown period                               | Configurable              |
| Flap suppression                              | Time-based                |
| Maintenance mode bypass                       | OK                        |
| Recovery-aware cooldown reset                 | Smart logic               |
| Multi-channel: Email + Telegram               | OK                        |

> [!TIP]
> **Kekuatan**: Alert logic sangat matang dengan cooldown, flap suppression, dan maintenance bypass. Recovery-aware cooldown yang membersihkan status saat sudah recover.

> [!WARNING]
> **Kelemahan**: Semua logic dalam fungsi prosedural tanpa class/interface; tidak extensible untuk channel baru (Slack, Discord, Webhook) tanpa modifikasi source; email channel menggunakan custom SMTP socket (bukan library PHPMailer/SwiftMailer).

#### Security

| Aspek                    | Implementasi                     | Detail                                                |
| ------------------------ | -------------------------------- | ----------------------------------------------------- |
| Password                 | bcrypt                           | Standard PHP `password_hash()`                        |
| Session                  | Secure cookies                   | httpOnly, SameSite=Lax, optional Secure flag          |
| CSRF                     | Token-based                      | Per-session CSRF token                                |
| Rate Limiting            | Login: DB-based, API: File-based | Sliding window, flock() atomic                        |
| Security Headers         | OK                               | HSTS, X-Frame-Options, X-Content-Type, XSS Protection |
| Session Timeout          | Idle + Absolute                  | Configurable, User-Agent validation                   |
| IP Source                | Trusted proxy chain              | CF/X-Real-IP/X-Forwarded-For dengan trust validation  |
| Sensitive Settings       | AES-256-CBC                      | Encrypted SMTP password & Telegram token              |
| Open Redirect Prevention | OK                               | Domain validation on redirect                         |
| Input Sanitization       | htmlspecialchars()               | Context-aware output escaping                         |

> [!TIP]
> **Kekuatan**: Security posture sangat baik — encrypted settings, proper session management, CSRF, rate limiting, IP trust chain.

> [!WARNING]
> **Kelemahan**: Tidak ada Content-Security-Policy header; custom SMTP client tanpa email header injection prevention; rate limiter berbasis file — tidak scalable di multi-server.

#### Frontend

- **CSS**: 1 file [app.css](file:///d:/SERVER/assets/css/app.css) — 1.679 baris custom design system
  - Dark and Light theme support
  - CSS custom properties (variables)
  - Glassmorphism, `color-mix()`, backdrop-filter effects
  - Sidebar layout, responsive breakpoints
- **JavaScript**: 10 files vanilla JS
  - Dashboard auto-refresh
  - Chart.js for server detail page
  - Theme toggling (localStorage)
  - Form validation
  - Sidebar collapse
- **No Frontend Framework**: Semua server-rendered PHP

> [!WARNING]
> **Kelemahan**: Tidak ada SPA/client-side routing; setiap navigasi = full page reload; tidak ada build pipeline (no bundling/minification); tidak ada TypeScript; Chart.js loaded dari CDN tanpa tree-shaking.

#### Agent ([agents/agent.sh](file:///d:/SERVER/agents/agent.sh) — 476 baris)

- Comprehensive bash agent with:
  - Auto panel detection (cPanel/Plesk/DirectAdmin/CyberPanel/aaPanel)
  - Service registry pattern with systemctl - service - pgrep fallback
  - Multi-MTA queue detection (Postfix/Exim/Qmail)
  - Network throughput calculation (delta bps)
  - Lock mechanism (flock)
  - HMAC request signing
  - JSON construction in pure bash

> [!TIP]
> **Kekuatan**: Sangat robust — defensive, fail-safe, panel-aware.

> [!WARNING]
> **Kelemahan**: 476 baris bash — sulit di-maintain dan di-test; manual JSON construction tanpa `jq`; terikat pada Linux (tidak cross-platform).

---

### 1.4 Database Schema — 14+ Tabel

| Tabel                                                         | Record Growth                     | Retention                      |
| ------------------------------------------------------------- | --------------------------------- | ------------------------------ |
| `metrics`                                                     | ~1 row/server/menit               | Configurable (default 30 hari) |
| `metrics_history`                                             | Aggregated archive                | 6x retention                   |
| `service_metrics`                                             | Per state change atau all samples | Configurable                   |
| `ping_checks`                                                 | Per interval per monitor          | Configurable                   |
| `alert_logs`                                                  | Event-driven                      | Configurable                   |
| `admin_audit_logs`                                            | Event-driven                      | Configurable                   |
| [login_attempts](file:///d:/SERVER/includes/auth.php#132-136) | Per failed login                  | Window-based cleanup           |

> [!CAUTION]
> Tabel `metrics` bisa membengkak sangat cepat (1 server = 1.440 row/hari = 43.200 row/bulan); query history 30d melibatkan UNION dua tabel besar; tidak ada time-series optimized storage; single MySQL tanpa read replica support.

---

### 1.5 Ringkasan Strengths & Weaknesses

#### Kekuatan Utama

1. **Feature-complete monitoring**: Server metrics, service status, ping, alerts, history
2. **Security matang**: HMAC signing, encrypted settings, session hardening, CSRF, rate limiting
3. **Alert system canggih**: Cooldown, flap suppression, maintenance bypass, multi-level thresholds
4. **Zero-dependency agent**: Pure bash, no external tools required
5. **Self-contained**: Single PHP app, no Composer dependencies, easy deployment
6. **Panel-aware**: Automatic detection for 6 hosting panels

#### Kelemahan Utama

1. **Monolithic PHP**: Tidak ada MVC/class-based architecture, semua prosedural
2. **No SPA frontend**: Setiap navigasi = full page reload, UX lambat
3. **No real-time updates**: Polling-based, tidak ada WebSocket/SSE
4. **Scalability terbatas**: Single MySQL, file-based rate limiting, synchronous workers
5. **No API versioning**: Satu versi endpoint, sulit evolve tanpa breaking change
6. **No build pipeline**: CSS/JS tidak minified/bundled, no TypeScript
7. **Vendor lock-in MySQL**: Hard-coded MySQL syntax di semua query
8. **No automated testing**: Hanya smoke tests, tidak ada unit/integration test suite
9. **No container support**: Tidak ada Dockerfile / docker-compose
10. **Complex history queries**: UNION-based aggregation sangat berat di scale besar

---
