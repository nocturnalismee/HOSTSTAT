# Analisis Mendalam & PRD: ServMon — Server Monitoring Website

---

## Bagian 1 — Analisis Komprehensif Codebase Saat Ini

### 1.1 Ringkasan Arsitektur

ServMon adalah aplikasi **self-hosted server monitoring** berbasis **PHP 8.2+ / MySQL 8.0** dengan arsitektur **push-based** dan rendering **server-side (SSR)**.

```mermaid
graph LR
    subgraph "Monitored Servers"
        A1[agent.sh] --> |HTTP POST + Token| B
        A2[agent-cpanel-mail.sh] --> |HTTP POST + Token| B
    end
    subgraph "ServMon Master"
        B["api/push.php"] --> C[(MySQL 8.0)]
        B --> D["Redis Cache"]
        E["workers/alert-check.php"] --> C
        F["workers/ping-check.php"] --> C
        G["workers/cleanup.php"] --> C
        H["admin/*.php"] --> C
        I["index.php - Public"] --> C
        J["api/status.php"] --> C
        E --> K["Notifications"]
        K --> K1["Email SMTP"]
        K --> K2["Telegram Bot"]
    end
    subgraph "End Users"
        L[Admin Browser] --> H
        M[Public Viewer] --> I
    end
```

| Aspek             | Detail                                                    |
| ----------------- | --------------------------------------------------------- |
| **Backend**       | PHP 8.2+, PDO/MySQL, custom SMTP socket, cURL             |
| **Database**      | MySQL 8.0, InnoDB, 14+ tabel                              |
| **Caching**       | Redis (opsional), in-memory PHP static vars               |
| **Frontend**      | Vanilla HTML/CSS/JS, Bootstrap grid system                |
| **Agent**         | Bash script (agent.sh), PHP agent stub                    |
| **Workers**       | 3 cron-based PHP scripts                                  |
| **Auth**          | Session-based, bcrypt password, role-based (admin/viewer) |
| **Notifications** | Email (native mail + custom SMTP), Telegram Bot API       |

---

### 1.2 Breakdown Modul & File

| Direktori   | Jumlah File       | Fungsi Utama                                                                       |
| ----------- | ----------------- | ---------------------------------------------------------------------------------- |
| `admin/`    | 14 PHP            | Dashboard, Server CRUD, Alert/Audit Logs, Settings, Ping Monitors, Export          |
| `agents/`   | 5 files + systemd | Bash push agent, cPanel mail agent, PHP agent stub                                 |
| [api/](file:///d:/SERVER/includes/rate_limiter.php#20-73)      | 5 PHP             | Push endpoint, Status/History API, Alert API, Health check                         |
| `assets/`   | 11 (1 CSS, 10 JS) | Design system, theme toggle, dashboard/detail/ping interactivity                   |
| `auth/`     | 2 PHP             | Login / Logout                                                                     |
| `includes/` | 17 PHP + 4 layout | Config, DB, Auth, Cache, Alerts, Settings, CSRF, Helpers, Ping, Rate Limiter, etc. |
| [sql/](file:///d:/SERVER/sql/seed.sql)      | 2 + 13 migrations | Schema, Seed, Incremental migrations                                               |
| `tests/`    | 7 files           | Smoke tests, Schema consistency, API smoke, AuthZ matrix, E2E scenarios            |
| `workers/`  | 3 PHP + 1 helper  | Alert check, Ping check, Cleanup/Retention                                         |

**Total: ~86 files, ~15.000 baris kode**

---

### 1.3 Analisis Per Komponen

#### Data Ingestion ([api/push.php](file:///d:/SERVER/api/push.php) — 488 baris)

| Fitur                    | Status       | Catatan                                                  |
| ------------------------ | ------------ | -------------------------------------------------------- |
| Token auth (64-char hex) | Solid        | Regex validation                                         |
| HMAC request signing     | Baik         | SHA-256, timestamp window 5 menit                        |
| IP allowlist per server  | Baik         | CIDR support                                             |
| Service status tracking  | Komprehensif | Panel-aware service registry, state transitions          |
| Panel profile detection  | Lengkap      | cPanel, Plesk, DirectAdmin, CyberPanel, aaPanel, Generic |
| Schema backward compat   | Defensif     | [db_column_exists()](file:///d:/SERVER/api/push.php#31-53) checks sebelum INSERT               |
| Mail queue ingestion     | Multi-MTA    | Postfix, Exim, Qmail                                     |

> [!TIP]
> **Kekuatan**: Defensif terhadap schema mismatch, backward compatible, multiple MTA support.

> [!WARNING]
> **Kelemahan**: File monolitik 488 baris tanpa class; banyak [db_column_exists()](file:///d:/SERVER/api/push.php#31-53) runtime check yang menambah query overhead; tidak ada request validation library (manual sepenuhnya).

#### Status & History API ([api/status.php](file:///d:/SERVER/api/status.php) — 247 baris)

| Fitur                            | Status | Catatan                               |
| -------------------------------- | ------ | ------------------------------------- |
| Server list + single detail      | OK     | Optimized JOIN via `latest_metric_id` |
| History aggregation (24h/7d/30d) | OK     | 5-min & 15-min bucketing              |
| Data point limiting              | OK     | Configurable 100-5000 points          |
| Redis caching                    | OK     | TTL per endpoint type                 |
| Rate limiting                    | OK     | File-based sliding window             |

> [!WARNING]
> **Kelemahan**: History SQL sangat kompleks — UNION ALL antara `metrics` dan `metrics_history` dengan nested subqueries; 7d/30d queries bisa sangat berat di database besar; tidak ada streaming/pagination untuk dataset besar.

#### Alert System ([includes/alerts.php](file:///d:/SERVER/includes/alerts.php) — 568 baris)

| Fitur                                         | Status                    |
| --------------------------------------------- | ------------------------- |
| Server down / recovery detection              | OK                        |
| Threshold alerts (CPU, RAM, Disk, Mail Queue) | Warning + Critical levels |
| Service transition alerts (up-down, down-up)  | OK                        |
| Ping monitor alerts (ICMP + HTTP)             | OK                        |
| Cooldown period                               | Configurable              |
| Flap suppression                              | Time-based                |
| Maintenance mode bypass                       | OK                        |
| Recovery-aware cooldown reset                 | Smart logic               |
| Multi-channel: Email + Telegram               | OK                        |

> [!TIP]
> **Kekuatan**: Alert logic sangat matang dengan cooldown, flap suppression, dan maintenance bypass. Recovery-aware cooldown yang membersihkan status saat sudah recover.

> [!WARNING]
> **Kelemahan**: Semua logic dalam fungsi prosedural tanpa class/interface; tidak extensible untuk channel baru (Slack, Discord, Webhook) tanpa modifikasi source; email channel menggunakan custom SMTP socket (bukan library PHPMailer/SwiftMailer).

#### Security

| Aspek                    | Implementasi                     | Detail                                                |
| ------------------------ | -------------------------------- | ----------------------------------------------------- |
| Password                 | bcrypt                           | Standard PHP `password_hash()`                        |
| Session                  | Secure cookies                   | httpOnly, SameSite=Lax, optional Secure flag          |
| CSRF                     | Token-based                      | Per-session CSRF token                                |
| Rate Limiting            | Login: DB-based, API: File-based | Sliding window, flock() atomic                        |
| Security Headers         | OK                               | HSTS, X-Frame-Options, X-Content-Type, XSS Protection |
| Session Timeout          | Idle + Absolute                  | Configurable, User-Agent validation                   |
| IP Source                | Trusted proxy chain              | CF/X-Real-IP/X-Forwarded-For dengan trust validation  |
| Sensitive Settings       | AES-256-CBC                      | Encrypted SMTP password & Telegram token              |
| Open Redirect Prevention | OK                               | Domain validation on redirect                         |
| Input Sanitization       | htmlspecialchars()               | Context-aware output escaping                         |

> [!TIP]
> **Kekuatan**: Security posture sangat baik — encrypted settings, proper session management, CSRF, rate limiting, IP trust chain.

> [!WARNING]
> **Kelemahan**: Tidak ada Content-Security-Policy header; custom SMTP client tanpa email header injection prevention; rate limiter berbasis file — tidak scalable di multi-server.

#### Frontend

- **CSS**: 1 file [app.css](file:///d:/SERVER/assets/css/app.css) — 1.679 baris custom design system
  - Dark and Light theme support
  - CSS custom properties (variables)
  - Glassmorphism, `color-mix()`, backdrop-filter effects
  - Sidebar layout, responsive breakpoints
- **JavaScript**: 10 files vanilla JS
  - Dashboard auto-refresh
  - Chart.js for server detail page
  - Theme toggling (localStorage)
  - Form validation
  - Sidebar collapse
- **No Frontend Framework**: Semua server-rendered PHP

> [!WARNING]
> **Kelemahan**: Tidak ada SPA/client-side routing; setiap navigasi = full page reload; tidak ada build pipeline (no bundling/minification); tidak ada TypeScript; Chart.js loaded dari CDN tanpa tree-shaking.

#### Agent ([agents/agent.sh](file:///d:/SERVER/agents/agent.sh) — 476 baris)

- Comprehensive bash agent with:
  - Auto panel detection (cPanel/Plesk/DirectAdmin/CyberPanel/aaPanel)
  - Service registry pattern with systemctl - service - pgrep fallback
  - Multi-MTA queue detection (Postfix/Exim/Qmail)
  - Network throughput calculation (delta bps)
  - Lock mechanism (flock)
  - HMAC request signing
  - JSON construction in pure bash

> [!TIP]
> **Kekuatan**: Sangat robust — defensive, fail-safe, panel-aware.

> [!WARNING]
> **Kelemahan**: 476 baris bash — sulit di-maintain dan di-test; manual JSON construction tanpa `jq`; terikat pada Linux (tidak cross-platform).

---

### 1.4 Database Schema — 14+ Tabel

| Tabel              | Record Growth                     | Retention                      |
| ------------------ | --------------------------------- | ------------------------------ |
| `metrics`          | ~1 row/server/menit               | Configurable (default 30 hari) |
| `metrics_history`  | Aggregated archive                | 6x retention                   |
| `service_metrics`  | Per state change atau all samples | Configurable                   |
| `ping_checks`      | Per interval per monitor          | Configurable                   |
| `alert_logs`       | Event-driven                      | Configurable                   |
| `admin_audit_logs` | Event-driven                      | Configurable                   |
| [login_attempts](file:///d:/SERVER/includes/auth.php#132-136)   | Per failed login                  | Window-based cleanup           |

> [!CAUTION]
> Tabel `metrics` bisa membengkak sangat cepat (1 server = 1.440 row/hari = 43.200 row/bulan); query history 30d melibatkan UNION dua tabel besar; tidak ada time-series optimized storage; single MySQL tanpa read replica support.

---

### 1.5 Ringkasan Strengths & Weaknesses

#### Kekuatan Utama

1. **Feature-complete monitoring**: Server metrics, service status, ping, alerts, history
2. **Security matang**: HMAC signing, encrypted settings, session hardening, CSRF, rate limiting
3. **Alert system canggih**: Cooldown, flap suppression, maintenance bypass, multi-level thresholds
4. **Zero-dependency agent**: Pure bash, no external tools required
5. **Self-contained**: Single PHP app, no Composer dependencies, easy deployment
6. **Panel-aware**: Automatic detection for 6 hosting panels

#### Kelemahan Utama

1. **Monolithic PHP**: Tidak ada MVC/class-based architecture, semua prosedural
2. **No SPA frontend**: Setiap navigasi = full page reload, UX lambat
3. **No real-time updates**: Polling-based, tidak ada WebSocket/SSE
4. **Scalability terbatas**: Single MySQL, file-based rate limiting, synchronous workers
5. **No API versioning**: Satu versi endpoint, sulit evolve tanpa breaking change
6. **No build pipeline**: CSS/JS tidak minified/bundled, no TypeScript
7. **Vendor lock-in MySQL**: Hard-coded MySQL syntax di semua query
8. **No automated testing**: Hanya smoke tests, tidak ada unit/integration test suite
9. **No container support**: Tidak ada Dockerfile / docker-compose
10. **Complex history queries**: UNION-based aggregation sangat berat di scale besar

---

---

## Bagian 2 — Product Requirements Document (PRD)

# PRD: ServMon v2.0 — Modern Server Monitoring Platform

## 2.1 Executive Summary

Membangun ulang ServMon menggunakan tech stack modern yang **ringan, scalable, real-time**, dan memberikan developer experience (DX) yang lebih baik — sambil mempertahankan semua fitur yang sudah production-ready dari versi PHP.

### Target Deployment

> [!NOTE]
> Aplikasi di-deploy pada **server Ubuntu dengan aaPanel** sebagai control panel. aaPanel digunakan untuk mengelola Nginx reverse proxy, Node.js process, PostgreSQL, dan Redis.

| Komponen | Setup di aaPanel |
|----------|------------------|
| **Reverse Proxy** | Nginx (managed via aaPanel Website Manager) — proxy pass ke Fastify (port 3001) dan Next.js (port 3000) |
| **Database** | PostgreSQL 16 — install via aaPanel Software Store atau manual apt |
| **Cache** | Redis 7 — install via aaPanel Software Store |
| **Process Manager** | PM2 — menjalankan Fastify API + Next.js sebagai background services |
| **SSL** | Let's Encrypt via aaPanel SSL Manager |
| **Node.js** | Node.js 20 LTS — install via aaPanel Node.js Version Manager |

**Konfigurasi Nginx di aaPanel:**
```nginx
# Reverse proxy untuk API (Fastify)
location /api/ {
    proxy_pass http://127.0.0.1:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

# Reverse proxy untuk Frontend (Next.js)
location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}

# WebSocket support untuk Socket.IO
location /socket.io/ {
    proxy_pass http://127.0.0.1:3001;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

---

## 2.2 Tech Stack Recommendation

### Backend

| Komponen          | Teknologi                                | Alasan                                                                           |
| ----------------- | ---------------------------------------- | -------------------------------------------------------------------------------- |
| **Runtime**       | **Node.js 20 LTS**                       | Non-blocking I/O ideal untuk monitoring; ecosystem besar; TypeScript first-class |
| **Framework**     | **Fastify**                              | 3x lebih cepat dari Express; schema validation built-in; plugin architecture     |
| **Language**      | **TypeScript**                           | Type-safety, refactor-friendly, auto-documented API                              |
| **ORM**           | **Drizzle ORM**                          | Lightweight, SQL-like, type-safe, zero-overhead                                  |
| **Database**      | **PostgreSQL 16**                        | Partitioning untuk time-series; JSONB; lebih kaya fitur dari MySQL               |
| **Cache**         | **Redis 7**                              | Sama seperti sekarang; digunakan untuk cache + rate limiting + pub/sub           |
| **Real-time**     | **Socket.IO / SSE**                      | Push updates ke dashboard tanpa polling                                          |
| **Queue**         | **BullMQ** (Redis-backed)                | Worker jobs: alerts, ping checks, cleanup                                        |
| **Auth**          | **JWT + Refresh Token**                  | Stateless, API-friendly, multi-device support                                    |
| **Notifications** | **Nodemailer + Telegram Bot + Webhooks** | Extensible notification channels                                                 |

### Frontend

| Komponen         | Teknologi                        | Alasan                                                              |
| ---------------- | -------------------------------- | ------------------------------------------------------------------- |
| **Framework**    | **Next.js 14 (App Router)**      | SSR + CSR hybrid; React ecosystem; API routes built-in              |
| **UI Library**   | **shadcn/ui + Radix**            | Accessible, customizable, no vendor lock-in                         |
| **Theme Editor** | **tweakcn**                      | Visual no-code theme editor untuk shadcn/ui; real-time preview; generates Tailwind CSS variables (v3/v4 compatible); palette, typography, radius, shadows customization |
| **Styling**      | **Tailwind CSS v4**              | Utility-first, design system tokens, dark mode built-in             |
| **Charts**       | **Recharts atau Tremor**         | React-native charting, responsive, lightweight                      |
| **State**        | **TanStack Query (React Query)** | Server state management, auto-refetch, caching                      |
| **Real-time**    | **Socket.IO Client**             | Live dashboard updates                                              |
| **Forms**        | **React Hook Form + Zod**        | Type-safe validation, performant                                    |

### Infrastructure

| Komponen             | Teknologi                           |
| -------------------- | ----------------------------------- |
| **Hosting**          | Ubuntu Server + aaPanel             |
| **Process Manager**  | PM2                                 |
| **Reverse Proxy**    | Nginx (via aaPanel)                 |
| **Containerization** | Docker + docker-compose (opsional)  |
| **CI/CD**            | GitHub Actions                      |
| **Testing**          | Vitest (unit) + Playwright (E2E)    |
| **Documentation**    | OpenAPI / Swagger auto-generated    |

---

## 2.3 Architecture Overview

```mermaid
graph TB
    subgraph "Monitored Servers"
        AG1["agent.sh / agent.ts"]
        AG2["cPanel Mail Agent"]
    end

    subgraph "ServMon v2.0"
        subgraph "API Layer - Fastify"
            PUSH["POST /api/v1/push"]
            STATUS["GET /api/v1/servers"]
            ALERTS["GET /api/v1/alerts"]
            AUTH["POST /api/v1/auth/*"]
            PING_API["GET /api/v1/ping-monitors"]
        end

        subgraph "Core Services"
            SVC_METRIC["MetricService"]
            SVC_ALERT["AlertService"]
            SVC_PING["PingService"]
            SVC_NOTIFY["NotificationService"]
            SVC_AUTH["AuthService"]
        end

        subgraph "Workers - BullMQ"
            W_ALERT["AlertCheckWorker"]
            W_PING["PingCheckWorker"]
            W_CLEANUP["RetentionCleanupWorker"]
            W_AGGREGATE["MetricAggregationWorker"]
        end

        subgraph "Data Layer"
            PG["PostgreSQL 16"]
            RD["Redis 7"]
        end

        subgraph "Real-time"
            WS["Socket.IO Server"]
        end
    end

    subgraph "Frontend - Next.js"
        DASH["Dashboard"]
        DETAIL["Server Detail"]
        ADMIN["Admin Panel"]
        PUBLIC["Public Status Page"]
    end

    AG1 --> PUSH
    AG2 --> PUSH
    PUSH --> SVC_METRIC --> PG
    SVC_METRIC --> RD
    SVC_METRIC --> WS

    W_ALERT --> SVC_ALERT --> SVC_NOTIFY
    W_PING --> SVC_PING
    W_CLEANUP --> PG

    WS --> DASH
    WS --> DETAIL
    DASH --> STATUS
    ADMIN --> AUTH
    PUBLIC --> STATUS
```

---

## 2.4 Functional Requirements

### FR-01: Metric Ingestion

- Agent push via `POST /api/v1/push` (backward compatible dengan agent.sh v2.0 yang sudah ada)
- Token + HMAC signature authentication (sama seperti sekarang)
- IP Allowlist per server
- Panel profile detection (cPanel, Plesk, etc.)
- Service status tracking dengan state transitions
- **UPDATED**: Payload agent mengirim metrik tambahan:
  - `ram_free` — free RAM dalam bytes (dihitung: `ram_total - ram_used`)
  - `disk_free` — free disk dalam bytes (dihitung: `disk_total - disk_used`)
  - Backend menghitung dan menyimpan kedua field ini di tabel `metrics`
  - Dashboard menampilkan free RAM & free disk di samping usage percentage
- **NEW**: WebSocket broadcast saat metric masuk - real-time dashboard update

### FR-02: Dashboard & Visualization

- Public status page (no auth) — server list, status badges, metrics summary
- Admin dashboard — summary cards, server table, alert/audit logs
- **NEW**: Real-time auto-update via WebSocket (tidak perlu refresh/polling)
- **NEW**: Interactive time-series charts dengan zoom/pan
- **NEW**: Customizable dashboard layout (drag-and-drop widgets)
- Compact view dan detail view
- Dark mode & light mode

### FR-03: Server Management

- CRUD server (add, edit, delete, activate/deactivate)
- Server detail page dengan historical charts (24h, 7d, 30d)
- Service status display per server
- Agent setup instructions (auto-generated per server)
- **NEW**: Server grouping dan tagging
- **NEW**: Bulk operations (activate/deactivate multiple)
- Maintenance mode toggle

### FR-04: Alert System

- Threshold alerts: CPU, RAM, Disk, Mail Queue (Warning + Critical levels)
- Server down / recovery detection
- Service transition alerts (up-down, down-up)
- Ping monitor alerts
- Configurable cooldown period
- Flap suppression
- Maintenance mode bypass
- Multi-channel notifications:
  - Email (SMTP)
  - Telegram
  - **NEW**: Slack
  - **NEW**: Discord
  - **NEW**: Generic Webhook
- **NEW**: Alert escalation rules
- **NEW**: Alert acknowledgment

### FR-05: Ping Monitoring

- ICMP ping monitoring
- HTTP/HTTPS health check
- Configurable interval, timeout, failure threshold
- Latency tracking dan history
- **NEW**: TCP port check
- **NEW**: DNS resolution check

### FR-06: Authentication & Authorization

- JWT-based authentication (access + refresh token)
- Role-based access: Admin, Viewer
- **NEW**: API key authentication untuk integrasi
- Login rate limiting
- Session blacklisting
- Audit logging

### FR-07: Settings & Configuration

- UI-configurable thresholds, cache TTL, notifications
- Branding (logo, favicon)
- Retention policy
- **NEW**: Per-server alert overrides
- **NEW**: Export/Import settings

### FR-08: Data Management

- Automatic data retention/cleanup via scheduled worker
- Metric aggregation (raw - hourly - daily)
- **NEW**: Data export (CSV, JSON)
- **NEW**: PostgreSQL table partitioning untuk time-series

---

## 2.5 Non-Functional Requirements

| Aspek                 | Target                  | Detail                                                  |
| --------------------- | ----------------------- | ------------------------------------------------------- |
| **Performance**       | < 100ms API response    | P95 latency untuk status endpoint                       |
| **Scalability**       | 500+ servers            | Horizontal scaling via multiple workers                 |
| **Availability**      | 99.9%                   | Health check endpoint, graceful degradation             |
| **Security**          | OWASP Top 10 compliance | JWT, RBAC, rate limiting, input validation, CSP headers |
| **Real-time**         | < 2s delay              | WebSocket push dari ingestion ke dashboard              |
| **Data Retention**    | Configurable 7-365 hari | Automatic aggregation + partitioned tables              |
| **Containerized**     | Docker first            | Single `docker-compose up` for full stack               |
| **API Documentation** | OpenAPI 3.0             | Auto-generated dari schema validation                   |

---

## 2.6 Project Structure

```
servmon-v2/
├── apps/
│   ├── api/                         # Fastify backend
│   │   ├── src/
│   │   │   ├── modules/
│   │   │   │   ├── auth/            # JWT auth, login, register
│   │   │   │   ├── servers/         # Server CRUD, metrics
│   │   │   │   ├── alerts/          # Alert system, thresholds
│   │   │   │   ├── ping/            # Ping monitoring
│   │   │   │   ├── notifications/   # Email, Telegram, Slack, Webhook
│   │   │   │   └── settings/        # App settings
│   │   │   ├── workers/             # BullMQ workers
│   │   │   ├── db/                  # Drizzle schema, migrations
│   │   │   ├── lib/                 # Shared utils, types
│   │   │   └── index.ts             # App entry
│   │   ├── drizzle.config.ts
│   │   └── package.json
│   │
│   └── web/                         # Next.js frontend
│       ├── src/
│       │   ├── app/                  # App Router pages
│       │   │   ├── (public)/        # Public status page
│       │   │   ├── (auth)/          # Login page
│       │   │   └── admin/           # Admin pages
│       │   ├── components/          # UI components
│       │   ├── hooks/               # Custom hooks
│       │   ├── lib/                 # API client, utils
│       │   └── styles/              # Tailwind config
│       └── package.json
│
├── agents/                          # Monitoring agents
│   ├── agent.sh                     # Bash agent (backward compat)
│   └── systemd/                     # Systemd templates
│
├── docker-compose.yml
├── Dockerfile.api
├── Dockerfile.web
└── package.json                     # Monorepo root
```

---

## 2.7 API Design (v1)

### Authentication

| Method | Endpoint               | Description             |
| ------ | ---------------------- | ----------------------- |
| POST   | `/api/v1/auth/login`   | Login, returns JWT pair |
| POST   | `/api/v1/auth/refresh` | Refresh access token    |
| POST   | `/api/v1/auth/logout`  | Blacklist refresh token |

### Servers

| Method | Endpoint                                 | Description                   |
| ------ | ---------------------------------------- | ----------------------------- |
| GET    | `/api/v1/servers`                        | List all servers              |
| GET    | `/api/v1/servers/:id`                    | Server detail + latest metric |
| GET    | `/api/v1/servers/:id/history?period=24h` | Historical metrics            |
| POST   | `/api/v1/servers`                        | Create server (admin)         |
| PATCH  | `/api/v1/servers/:id`                    | Update server (admin)         |
| DELETE | `/api/v1/servers/:id`                    | Delete server (admin)         |

### Metric Push (Agent)

| Method | Endpoint       | Description               |
| ------ | -------------- | ------------------------- |
| POST   | `/api/v1/push` | Push metrics (token auth) |

### Alerts

| Method | Endpoint                         | Description       |
| ------ | -------------------------------- | ----------------- |
| GET    | `/api/v1/alerts`                 | List alert logs   |
| POST   | `/api/v1/alerts/:id/acknowledge` | Acknowledge alert |

### Ping Monitors

| Method | Endpoint                            | Description    |
| ------ | ----------------------------------- | -------------- |
| GET    | `/api/v1/ping-monitors`             | List monitors  |
| POST   | `/api/v1/ping-monitors`             | Create monitor |
| GET    | `/api/v1/ping-monitors/:id/history` | Check history  |

### Settings

| Method | Endpoint           | Description      |
| ------ | ------------------ | ---------------- |
| GET    | `/api/v1/settings` | Get all settings |
| PATCH  | `/api/v1/settings` | Update settings  |

---

## 2.8 Database Schema (PostgreSQL)

### Key Tables

```sql
-- Partitioned by month for performance
CREATE TABLE metrics (
    id          BIGSERIAL,
    server_id   INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    uptime      BIGINT DEFAULT 0,
    cpu_load    DECIMAL(8,4) DEFAULT 0,
    ram_total   BIGINT DEFAULT 0,
    ram_used    BIGINT DEFAULT 0,
    ram_free    BIGINT DEFAULT 0,       -- NEW: free RAM (bytes)
    disk_total  BIGINT DEFAULT 0,
    disk_used   BIGINT DEFAULT 0,
    disk_free   BIGINT DEFAULT 0,       -- NEW: free disk (bytes)
    net_in_bps  BIGINT DEFAULT 0,
    net_out_bps BIGINT DEFAULT 0,
    mail_mta    VARCHAR(20) DEFAULT 'none',
    mail_queue  INTEGER DEFAULT 0,
    panel       VARCHAR(20) DEFAULT 'generic',
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (id, recorded_at)
) PARTITION BY RANGE (recorded_at);

-- Automatically create monthly partitions
-- pg_partman or custom migration script
```

#### Agent Payload (Updated)

Payload JSON dari [agent.sh](file:///d:/SERVER/agents/agent.sh) diperluas dengan field `ram_free` dan `disk_free`:

```json
{
  "server_id": 1,
  "uptime": 86400,
  "ram_total": 8589934592,
  "ram_used": 4294967296,
  "ram_free": 4294967296,
  "hdd_total": 107374182400,
  "hdd_used": 53687091200,
  "hdd_free": 53687091200,
  "cpu_load": 1.25,
  "network": { "in_bps": 150000, "out_bps": 80000 },
  "mail": { "mta": "postfix", "queue_total": 5 },
  "panel_profile": "cpanel",
  "services": [...]
}
```

Pada bash agent, metrik ditambahkan:
```bash
# RAM: total, used, free
collect_ram() {
  free -b | awk '/^Mem:/ {print $2, $3, $4}'
}
read -r ram_total ram_used ram_free <<< "$(collect_ram)"

# Disk: total, used, free
collect_disk() {
  df -PB1 / | awk 'NR==2 {print $2, $3, $4}'
}
read -r hdd_total hdd_used hdd_free <<< "$(collect_disk)"
```

### Advantages over MySQL

- **Table partitioning** untuk time-series data - query history jauh lebih cepat
- **JSONB** untuk extensible metadata tanpa schema migration
- **TIMESTAMPTZ** untuk timezone-aware timestamps
- **Parallel query** untuk aggregate queries

---

## 2.9 Migration Strategy dari PHP

| Fase                   | Durasi Estimasi | Scope                                                      |
| ---------------------- | --------------- | ---------------------------------------------------------- |
| **Fase 1 — Core**      | 3-4 minggu      | API setup, auth, server CRUD, metric push, basic dashboard |
| **Fase 2 — Features**  | 2-3 minggu      | Alerts, notifications, ping monitoring, settings           |
| **Fase 3 — Real-time** | 1-2 minggu      | WebSocket integration, live dashboard                      |
| **Fase 4 — Polish**    | 1-2 minggu      | Charts, dark mode, responsive design, data export          |
| **Fase 5 — DevOps**    | 1 minggu        | Docker, CI/CD, documentation, testing                      |

### Backward Compatibility

- **Agent [agent.sh](file:///d:/SERVER/agents/agent.sh)**: Push endpoint `/api/v1/push` harus 100% kompatibel dengan format payload agent.sh v2.0 yang ada
- **Database migration**: Script konversi data dari MySQL ke PostgreSQL
- **Configuration**: Environment variable names tetap sama

---

## 2.10 Key Differentiators vs Current Version

| Fitur                 | PHP (Current)                 | v2.0 (Modern)                            |
| --------------------- | ----------------------------- | ---------------------------------------- |
| Dashboard update      | Polling setiap 30-60 detik    | Real-time WebSocket (< 2 detik)          |
| Page navigation       | Full page reload              | SPA client-side routing                  |
| API                   | Server-rendered HTML          | RESTful JSON API + OpenAPI docs          |
| Type safety           | None (runtime errors)         | TypeScript end-to-end                    |
| Testing               | Smoke tests only              | Unit + Integration + E2E                 |
| Deployment            | Manual PHP upload             | `docker-compose up`                      |
| Time-series perf      | UNION queries on large tables | PostgreSQL partitioned tables            |
| Notification channels | Email + Telegram only         | Email, Telegram, Slack, Discord, Webhook |
| Frontend              | 1679-line custom CSS          | Tailwind + Design system + Components    |
| Build pipeline        | None                          | Bundled, minified, tree-shaken           |

---

## 2.11 Risk & Mitigation

| Risk                         | Impact                              | Mitigation                                       |
| ---------------------------- | ----------------------------------- | ------------------------------------------------ |
| Breaking agent compatibility | Semua monitored server harus update | Endpoint push 100% backward compatible           |
| Data migration complexity    | Data loss                           | Thorough migration script + dry-run mode         |
| Learning curve               | Tim perlu belajar TypeScript/React  | Comprehensive documentation                      |
| Over-engineering             | Delay delivery                      | Fase 1 fokus feature parity, baru tambahan fitur |

---

> [!IMPORTANT]
> **Rekomendasi**: Mulai dari **Fase 1** (core API + basic dashboard) untuk mendapatkan feature parity dengan versi PHP. Agent backward compatibility adalah prioritas #1 agar transisi bisa gradual tanpa downtime di monitored servers.
