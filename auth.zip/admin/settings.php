<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/settings.php';
require_once __DIR__ . '/../includes/alerts.php';
require_once __DIR__ . '/../includes/cache.php';
require_once __DIR__ . '/../includes/audit.php';
require_once __DIR__ . '/../includes/worker.php';
require_once __DIR__ . '/../includes/retention.php';

require_role('admin');

function normalize_user_role(?string $role): string
{
    $role = strtolower(trim((string) $role));
    return in_array($role, ['admin', 'viewer'], true) ? $role : 'viewer';
}

function admin_user_count(): int
{
    $row = db_one('SELECT COUNT(*) AS total FROM users WHERE role = "admin"');
    return (int) ($row['total'] ?? 0);
}

function settings_section_map(): array
{
    return [
        'general' => 'General',
        'notifications' => 'Notifications',
        'security' => 'Security',
        'users' => 'Users',
        'ops' => 'Ops',
    ];
}

function normalize_settings_section(?string $section): string
{
    $section = strtolower(trim((string) $section));
    return array_key_exists($section, settings_section_map()) ? $section : 'general';
}

function infer_section_from_post(array $post): string
{
    if (isset($post['section'])) {
        return normalize_settings_section((string) $post['section']);
    }

    $action = (string) ($post['action'] ?? '');
    if (in_array($action, ['test_email', 'test_telegram'], true)) {
        return 'notifications';
    }
    if ($action === 'run_retention') {
        return 'security';
    }
    if (str_starts_with($action, 'user_')) {
        return 'users';
    }
    if (isset($post['smtp_host']) || isset($post['telegram_bot_token']) || isset($post['channel_email_enabled']) || isset($post['channel_telegram_enabled'])) {
        return 'notifications';
    }
    if (isset($post['session_idle_timeout_minutes']) || isset($post['session_absolute_timeout_minutes']) || isset($post['retention_days']) || isset($post['disk_retention_days'])) {
        return 'security';
    }

    return 'general';
}

function settings_url(string $section): string
{
    return '/admin/settings.php?section=' . rawurlencode(normalize_settings_section($section));
}

if (is_post()) {
    $section = infer_section_from_post($_POST);
    if (!csrf_validate($_POST['_csrf_token'] ?? null)) {
        flash_set('danger', 'Invalid CSRF token.');
        redirect(settings_url($section));
    }

    $action = (string) ($_POST['action'] ?? 'save');

    if ($action === 'save') {
        $values = [];
        if ($section === 'general') {
            $values = [
                'branding_logo_url' => trim((string) ($_POST['branding_logo_url'] ?? setting_get('branding_logo_url'))),
                'branding_favicon_url' => trim((string) ($_POST['branding_favicon_url'] ?? setting_get('branding_favicon_url'))),
                'alert_down_minutes' => (string) max(1, (int) ($_POST['alert_down_minutes'] ?? setting_get('alert_down_minutes'))),
                'alert_cooldown_minutes' => (string) max(0, (int) ($_POST['alert_cooldown_minutes'] ?? setting_get('alert_cooldown_minutes'))),
                'alert_service_status_enabled' => isset($_POST['alert_service_status_enabled']) ? '1' : '0',
                'alert_ping_enabled' => isset($_POST['alert_ping_enabled']) ? '1' : '0',
                'threshold_mail_queue' => (string) max(0, (int) ($_POST['threshold_mail_queue'] ?? setting_get('threshold_mail_queue'))),
                'threshold_mail_queue_critical' => (string) max(0, (int) ($_POST['threshold_mail_queue_critical'] ?? setting_get('threshold_mail_queue_critical'))),
                'threshold_cpu_load' => (string) max(0, (float) ($_POST['threshold_cpu_load'] ?? setting_get('threshold_cpu_load'))),
                'threshold_cpu_load_critical' => (string) max(0, (float) ($_POST['threshold_cpu_load_critical'] ?? setting_get('threshold_cpu_load_critical'))),
                'threshold_ram_pct' => (string) max(0, min(100, (float) ($_POST['threshold_ram_pct'] ?? setting_get('threshold_ram_pct')))),
                'threshold_ram_pct_critical' => (string) max(0, min(100, (float) ($_POST['threshold_ram_pct_critical'] ?? setting_get('threshold_ram_pct_critical')))),
                'threshold_disk_pct' => (string) max(0, min(100, (float) ($_POST['threshold_disk_pct'] ?? setting_get('threshold_disk_pct')))),
                'threshold_disk_pct_critical' => (string) max(0, min(100, (float) ($_POST['threshold_disk_pct_critical'] ?? setting_get('threshold_disk_pct_critical')))),
                'alert_service_flap_suppress_minutes' => (string) max(0, (int) ($_POST['alert_service_flap_suppress_minutes'] ?? setting_get('alert_service_flap_suppress_minutes'))),
                'public_alerts_redact_message' => isset($_POST['public_alerts_redact_message']) ? '1' : '0',
                'cache_ttl_status_list' => (string) max(1, (int) ($_POST['cache_ttl_status_list'] ?? setting_get('cache_ttl_status_list'))),
                'cache_ttl_status_single' => (string) max(1, (int) ($_POST['cache_ttl_status_single'] ?? setting_get('cache_ttl_status_single'))),
                'cache_ttl_history_24h' => (string) max(1, (int) ($_POST['cache_ttl_history_24h'] ?? setting_get('cache_ttl_history_24h'))),
                'cache_ttl_history_7d' => (string) max(1, (int) ($_POST['cache_ttl_history_7d'] ?? setting_get('cache_ttl_history_7d'))),
                'cache_ttl_history_30d' => (string) max(1, (int) ($_POST['cache_ttl_history_30d'] ?? setting_get('cache_ttl_history_30d'))),
                'cache_ttl_alert_logs' => (string) max(1, (int) ($_POST['cache_ttl_alert_logs'] ?? setting_get('cache_ttl_alert_logs'))),
            ];
        } elseif ($section === 'notifications') {
            $values = [
                'channel_email_enabled' => isset($_POST['channel_email_enabled']) ? '1' : '0',
                'channel_telegram_enabled' => isset($_POST['channel_telegram_enabled']) ? '1' : '0',
                'smtp_host' => trim((string) ($_POST['smtp_host'] ?? setting_get('smtp_host'))),
                'smtp_port' => (string) max(1, (int) ($_POST['smtp_port'] ?? setting_get('smtp_port'))),
                'smtp_username' => trim((string) ($_POST['smtp_username'] ?? setting_get('smtp_username'))),
                'smtp_secure' => in_array((string) ($_POST['smtp_secure'] ?? setting_get('smtp_secure')), ['none', 'tls', 'ssl'], true) ? (string) ($_POST['smtp_secure'] ?? setting_get('smtp_secure')) : 'tls',
                'smtp_from_email' => trim((string) ($_POST['smtp_from_email'] ?? setting_get('smtp_from_email'))),
                'smtp_from_name' => trim((string) ($_POST['smtp_from_name'] ?? setting_get('smtp_from_name'))),
                'smtp_to_email' => trim((string) ($_POST['smtp_to_email'] ?? setting_get('smtp_to_email'))),
                'telegram_bot_token' => trim((string) ($_POST['telegram_bot_token'] ?? setting_get('telegram_bot_token'))),
                'telegram_chat_id' => trim((string) ($_POST['telegram_chat_id'] ?? setting_get('telegram_chat_id'))),
                'telegram_thread_id' => trim((string) ($_POST['telegram_thread_id'] ?? setting_get('telegram_thread_id'))),
            ];
            $newSmtpPassword = trim((string) ($_POST['smtp_password'] ?? ''));
            if ($newSmtpPassword !== '') {
                $values['smtp_password'] = $newSmtpPassword;
            }
        } elseif ($section === 'security') {
            $values = [
                'session_idle_timeout_minutes' => (string) max(5, (int) ($_POST['session_idle_timeout_minutes'] ?? setting_get('session_idle_timeout_minutes'))),
                'session_absolute_timeout_minutes' => (string) max(15, (int) ($_POST['session_absolute_timeout_minutes'] ?? setting_get('session_absolute_timeout_minutes'))),
                'retention_days' => (string) max(1, (int) ($_POST['retention_days'] ?? setting_get('retention_days'))),
                'disk_retention_days' => (string) max(1, (int) ($_POST['disk_retention_days'] ?? setting_get('disk_retention_days'))),
            ];
        }

        if (!empty($values)) {
            settings_save_many($values);
            invalidate_status_cache();
            audit_log('settings_save', 'Updated application settings', 'settings', null, [
                'section' => $section,
                'updated_keys' => array_keys($values),
            ]);
            flash_set('success', 'Settings saved successfully.');
        } else {
            flash_set('warning', 'No settings updated for this section.');
        }
        redirect(settings_url($section));
    }

    if ($action === 'test_email') {
        $settings = settings_get_all();
        $ok = notify_email('servmon Test Notification', 'This is a test email notification from servmon.', $settings);
        audit_log('settings_test_email', 'Ran test email notification', 'settings');
        flash_set($ok ? 'success' : 'warning', $ok ? 'Test email sent.' : 'Test email failed. Check configuration or server mail() support.');
        redirect(settings_url('notifications'));
    }

    if ($action === 'test_telegram') {
        $settings = settings_get_all();
        $settings['channel_telegram_enabled'] = '1';
        $settings['telegram_bot_token'] = trim((string) ($_POST['telegram_bot_token'] ?? $settings['telegram_bot_token'] ?? ''));
        $settings['telegram_chat_id'] = trim((string) ($_POST['telegram_chat_id'] ?? $settings['telegram_chat_id'] ?? ''));
        $settings['telegram_thread_id'] = trim((string) ($_POST['telegram_thread_id'] ?? $settings['telegram_thread_id'] ?? ''));
        $ok = notify_telegram("<b>servmon Test Notification</b>\nThis is a Telegram test notification.", $settings);
        audit_log('settings_test_telegram', 'Ran test telegram notification', 'settings');
        flash_set($ok ? 'success' : 'warning', $ok ? 'Test Telegram message sent.' : 'Test Telegram failed. Check bot token and chat ID. Thread ID is optional.');
        redirect(settings_url('notifications'));
    }

    if ($action === 'run_retention') {
        $days = max(1, (int) ($_POST['retention_days'] ?? setting_get('retention_days')));
        $result = run_core_retention_cleanup($days);
        audit_log('settings_run_retention', 'Executed retention cleanup from settings', 'settings', null, ['days' => $days, 'result' => $result]);
        flash_set(
            'success',
            'Core retention completed (cutoff: ' . ($result['cutoff_at'] ?? '-') . '). Service Metrics: ' . ($result['service_metrics_deleted'] ?? 0)
            . ', Metrics: ' . $result['metrics_deleted']
            . ', Ping Checks: ' . ($result['ping_checks_deleted'] ?? 0)
            . ', Alerts: ' . $result['alerts_deleted']
            . ', Login Attempts: ' . $result['attempts_deleted']
            . ', Audit Logs: ' . ($result['audits_deleted'] ?? 0)
        );
        redirect(settings_url('security'));
    }

    if ($action === 'run_disk_retention') {
        $days = max(1, (int) ($_POST['disk_retention_days'] ?? setting_get('disk_retention_days')));
        $result = run_disk_retention_cleanup($days);
        audit_log('settings_run_disk_retention', 'Executed disk retention cleanup from settings', 'settings', null, ['days' => $days, 'result' => $result]);
        flash_set(
            'success',
            'Disk retention completed (cutoff: ' . ($result['cutoff_at'] ?? '-') . '). Disk Metrics: '
            . ($result['disk_metrics_deleted'] ?? 0)
            . ', Disk History: ' . ($result['disk_history_deleted'] ?? 0)
        );
        redirect(settings_url('security'));
    }

    if ($action === 'user_create') {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $role = normalize_user_role($_POST['role'] ?? 'viewer');

        if ($username === '' || preg_match('/^[a-zA-Z0-9_.-]{3,50}$/', $username) !== 1) {
            flash_set('danger', 'Invalid username format. Use 3-50 chars: letters, numbers, dot, underscore, hyphen.');
            redirect(settings_url('users'));
        }
        if (strlen($password) < 8) {
            flash_set('danger', 'User password must be at least 8 characters.');
            redirect(settings_url('users'));
        }
        if (db_one('SELECT id FROM users WHERE username = :username LIMIT 1', [':username' => $username]) !== null) {
            flash_set('danger', 'Username already exists.');
            redirect(settings_url('users'));
        }

        db_exec(
            'INSERT INTO users (username, password_hash, role, created_at) VALUES (:username, :password_hash, :role, NOW())',
            [
                ':username' => $username,
                ':password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
                ':role' => $role,
            ]
        );
        $newUserId = (int) db()->lastInsertId();
        audit_log('user_create', 'Created user account', 'user', $newUserId, ['username' => $username, 'role' => $role]);
        flash_set('success', 'User created successfully.');
        redirect(settings_url('users'));
    }

    if ($action === 'user_update') {
        $userId = (int) ($_POST['user_id'] ?? 0);
        $role = normalize_user_role($_POST['role'] ?? 'viewer');
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $target = db_one('SELECT id, username, role FROM users WHERE id = :id LIMIT 1', [':id' => $userId]);
        $current = current_user();
        $currentUserId = (int) ($current['id'] ?? 0);

        if ($target === null || $userId <= 0) {
            flash_set('danger', 'User not found.');
            redirect(settings_url('users'));
        }
        if ($userId === $currentUserId && $role !== 'admin') {
            flash_set('danger', 'You cannot downgrade your own role.');
            redirect(settings_url('users'));
        }
        if ((string) $target['role'] === 'admin' && $role !== 'admin' && admin_user_count() <= 1) {
            flash_set('danger', 'Cannot remove role from the last admin user.');
            redirect(settings_url('users'));
        }
        if ($newPassword !== '' && strlen($newPassword) < 8) {
            flash_set('danger', 'New password must be at least 8 characters.');
            redirect(settings_url('users'));
        }

        db_exec('UPDATE users SET role = :role WHERE id = :id', [':role' => $role, ':id' => $userId]);
        if ($newPassword !== '') {
            db_exec(
                'UPDATE users SET password_hash = :password_hash WHERE id = :id',
                [':password_hash' => password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]), ':id' => $userId]
            );
        }

        audit_log(
            'user_update',
            'Updated user account',
            'user',
            $userId,
            ['username' => $target['username'], 'role' => $role, 'password_changed' => $newPassword !== '']
        );
        flash_set('success', 'User updated successfully.');
        redirect(settings_url('users'));
    }

    if ($action === 'user_delete') {
        $userId = (int) ($_POST['user_id'] ?? 0);
        $target = db_one('SELECT id, username, role FROM users WHERE id = :id LIMIT 1', [':id' => $userId]);
        $current = current_user();
        $currentUserId = (int) ($current['id'] ?? 0);

        if ($target === null || $userId <= 0) {
            flash_set('danger', 'User not found.');
            redirect(settings_url('users'));
        }
        if ($userId === $currentUserId) {
            flash_set('danger', 'You cannot delete your own account.');
            redirect(settings_url('users'));
        }
        if ((string) $target['role'] === 'admin' && admin_user_count() <= 1) {
            flash_set('danger', 'Cannot delete the last admin user.');
            redirect(settings_url('users'));
        }

        db_exec('DELETE FROM users WHERE id = :id', [':id' => $userId]);
        audit_log('user_delete', 'Deleted user account', 'user', $userId, ['username' => $target['username'], 'role' => $target['role']]);
        flash_set('success', 'User deleted successfully.');
        redirect(settings_url('users'));
    }
}

$sections = settings_section_map();
$activeSection = normalize_settings_section($_GET['section'] ?? 'general');
$settings = settings_get_all();
$users = db_all('SELECT id, username, role, last_login, created_at FROM users ORDER BY created_at ASC');
$currentUser = current_user();
$adminCount = 0;
foreach ($users as $u) {
    if ((string) ($u['role'] ?? '') === 'admin') {
        $adminCount++;
    }
}

$projectRoot = realpath(__DIR__ . '/..');
if (!is_string($projectRoot) || $projectRoot === '') {
    $projectRoot = dirname(__DIR__);
}
$phpCron = '/usr/bin/php';
$workersRoot = rtrim(str_replace('\\', '/', $projectRoot), '/');
$alertWorker = $workersRoot . '/workers/alert-check.php';
$pingWorker = $workersRoot . '/workers/ping-check.php';
$retentionWorker = $workersRoot . '/workers/cleanup.php';
$diskRetentionWorker = $workersRoot . '/workers/disk-cleanup.php';
$recommendedCron = [
    '* * * * * ' . $phpCron . ' ' . $alertWorker . ' >/dev/null 2>&1',
    '* * * * * ' . $phpCron . ' ' . $pingWorker . ' >/dev/null 2>&1',
    '30 2 * * * ' . $phpCron . ' ' . $diskRetentionWorker . ' >/dev/null 2>&1',
    '0 3 * * * ' . $phpCron . ' ' . $retentionWorker . ' >/dev/null 2>&1',
];
$workerStatuses = [
    'alert_check' => worker_health_status('alert_check', 180),
    'ping_check' => worker_health_status('ping_check', 300),
    'disk_retention_cleanup' => worker_health_status('disk_retention_cleanup', 129600),
    'retention_cleanup' => worker_health_status('retention_cleanup', 129600),
];
$activeSectionLabel = $sections[$activeSection] ?? ucfirst($activeSection);
$sectionActionHints = [
    'general' => 'Save once after updating policy, threshold, and cache values.',
    'notifications' => 'Save config first, then run test delivery.',
    'security' => 'Save timeout/retention changes before running cleanup.',
    'users' => 'User add/edit/delete is applied immediately after submit.',
    'ops' => 'Monitor worker health and keep cron jobs active.',
];
$activeSectionHint = $sectionActionHints[$activeSection] ?? 'Manage this section using the controls below.';

$title = APP_NAME . ' - Settings';
$activeNav = 'settings';

require_once __DIR__ . '/../includes/layout/head.php';
require_once __DIR__ . '/../includes/layout/nav.php';
require_once __DIR__ . '/../includes/layout/flash.php';
?>
<main class="container py-4 admin-page admin-shell">
    <section class="page-header" data-ui-toolbar>
        <div>
            <h1 class="page-title">Settings</h1>
            <p class="page-subtitle">Configure alerts, channels, retention, security, and user access in one workspace.</p>
        </div>
    </section>
    <section class="card card-neon" data-ui-section>
        <div class="card-body p-3 p-lg-4">
            <nav class="settings-tabs nav nav-pills" aria-label="Settings Sections">
                <?php foreach ($sections as $key => $label): ?>
                    <a
                        class="settings-tab nav-link <?= $activeSection === $key ? 'active' : '' ?>"
                        href="<?= e(app_url('admin/settings.php?section=' . $key)) ?>"
                        <?= $activeSection === $key ? 'aria-current="page"' : '' ?>
                    ><?= e($label) ?></a>
                <?php endforeach; ?>
            </nav>
            <p class="settings-section-intro mb-0">
                <?php if ($activeSection === 'general'): ?>
                    Branding, alert policy, thresholds, and cache behavior.
                <?php elseif ($activeSection === 'notifications'): ?>
                    Email and Telegram channel configuration plus test actions.
                <?php elseif ($activeSection === 'security'): ?>
                    Session timeout and retention controls.
                <?php elseif ($activeSection === 'users'): ?>
                    Manage admin and viewer access accounts.
                <?php else: ?>
                    Operational references for worker and runtime checks.
                <?php endif; ?>
            </p>
            <div class="settings-overview mt-3">
                <span class="settings-kpi">Active section: <strong><?= e($activeSectionLabel) ?></strong></span>
                <span class="settings-kpi"><?= e($activeSectionHint) ?></span>
            </div>
        </div>
    </section>
    <?php if (in_array($activeSection, ['general', 'notifications', 'security'], true)): ?>
    <form method="post" class="card card-neon" data-ui-section>
        <?= csrf_input() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="section" value="<?= e($activeSection) ?>">
        <?php if ($activeSection === 'general'): ?>
        <div class="card-header bg-surface-2 border-soft">Branding</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12 col-lg-6">
                    <label class="form-label">Brand Logo URL</label>
                    <input class="form-control" name="branding_logo_url" placeholder="/assets/img/logo.svg atau https://..." value="<?= e($settings['branding_logo_url'] ?? '') ?>">
                    <div class="field-help">Digunakan untuk logo di sidebar dan halaman publik.</div>
                </div>
                <div class="col-12 col-lg-6">
                    <label class="form-label">Favicon URL</label>
                    <input class="form-control" name="branding_favicon_url" placeholder="/assets/img/favicon.ico atau https://..." value="<?= e($settings['branding_favicon_url'] ?? '') ?>">
                    <div class="field-help">Mendukung .ico, .png, .svg, atau URL absolut.</div>
                </div>
            </div>
        </div>
        <div class="card-header bg-surface-2 border-soft">Alerts & Thresholds</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label">Down Duration (minutes)</label>
                    <input class="form-control" type="number" min="1" name="alert_down_minutes" value="<?= e($settings['alert_down_minutes']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Alert Cooldown (minutes)</label>
                    <input class="form-control" type="number" min="0" name="alert_cooldown_minutes" value="<?= e($settings['alert_cooldown_minutes']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label d-block">Service Status Alerts</label>
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="alert_service_status_enabled" id="alert_service_status_enabled" <?= ($settings['alert_service_status_enabled'] ?? '1') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="alert_service_status_enabled">Enable Service UP/DOWN Alerts</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label d-block">Ping Alerts</label>
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="alert_ping_enabled" id="alert_ping_enabled" <?= ($settings['alert_ping_enabled'] ?? '1') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="alert_ping_enabled">Enable Ping UP/DOWN Alerts</label>
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold Mail Queue</label>
                    <input class="form-control" type="number" min="0" name="threshold_mail_queue" value="<?= e($settings['threshold_mail_queue']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold CPU Load</label>
                    <input class="form-control" type="number" step="0.01" min="0" name="threshold_cpu_load" value="<?= e($settings['threshold_cpu_load']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold CPU Critical</label>
                    <input class="form-control" type="number" step="0.01" min="0" name="threshold_cpu_load_critical" value="<?= e($settings['threshold_cpu_load_critical']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold RAM (%)</label>
                    <input class="form-control" type="number" step="0.1" min="0" max="100" name="threshold_ram_pct" value="<?= e($settings['threshold_ram_pct']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold Disk (%)</label>
                    <input class="form-control" type="number" step="0.1" min="0" max="100" name="threshold_disk_pct" value="<?= e($settings['threshold_disk_pct']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold Mail Queue Critical</label>
                    <input class="form-control" type="number" min="0" name="threshold_mail_queue_critical" value="<?= e($settings['threshold_mail_queue_critical']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold RAM Critical (%)</label>
                    <input class="form-control" type="number" step="0.1" min="0" max="100" name="threshold_ram_pct_critical" value="<?= e($settings['threshold_ram_pct_critical']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Threshold Disk Critical (%)</label>
                    <input class="form-control" type="number" step="0.1" min="0" max="100" name="threshold_disk_pct_critical" value="<?= e($settings['threshold_disk_pct_critical']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Service Flap Suppress (minutes)</label>
                    <input class="form-control" type="number" min="0" name="alert_service_flap_suppress_minutes" value="<?= e($settings['alert_service_flap_suppress_minutes']) ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label d-block">Public Alert Message</label>
                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="public_alerts_redact_message" id="public_alerts_redact_message" <?= ($settings['public_alerts_redact_message'] ?? '0') === '1' ? 'checked' : '' ?>>
                        <label class="form-check-label" for="public_alerts_redact_message">Redact public alert message</label>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($activeSection === 'notifications'): ?>
        <div class="card-header bg-surface-2 border-soft">Notification Channels</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-12 col-xl-8">
                    <div class="border-soft rounded-3 p-3 h-100">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h2 class="h6 mb-0">Email</h2>
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="checkbox" name="channel_email_enabled" id="channel_email_enabled" <?= $settings['channel_email_enabled'] === '1' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="channel_email_enabled">Enable Email</label>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Notification Recipient Email</label>
                                <input class="form-control" name="smtp_to_email" value="<?= e($settings['smtp_to_email']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">SMTP Host</label>
                                <input class="form-control" name="smtp_host" value="<?= e($settings['smtp_host']) ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">SMTP Port</label>
                                <input class="form-control" type="number" name="smtp_port" value="<?= e($settings['smtp_port']) ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">SMTP Secure</label>
                                <select class="form-select" name="smtp_secure">
                                    <option value="none" <?= $settings['smtp_secure'] === 'none' ? 'selected' : '' ?>>None</option>
                                    <option value="tls" <?= $settings['smtp_secure'] === 'tls' ? 'selected' : '' ?>>TLS</option>
                                    <option value="ssl" <?= $settings['smtp_secure'] === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">SMTP Username</label>
                                <input class="form-control" name="smtp_username" value="<?= e($settings['smtp_username']) ?>">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">SMTP Password</label>
                                <input class="form-control" type="password" name="smtp_password" placeholder="Leave blank to keep current password">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Sender Email</label>
                                <input class="form-control" name="smtp_from_email" value="<?= e($settings['smtp_from_email']) ?>">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label">Sender Name</label>
                                <input class="form-control" name="smtp_from_name" value="<?= e($settings['smtp_from_name']) ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-xl-4">
                    <div class="border-soft rounded-3 p-3 h-100">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h2 class="h6 mb-0">Telegram</h2>
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="checkbox" name="channel_telegram_enabled" id="channel_telegram_enabled" <?= $settings['channel_telegram_enabled'] === '1' ? 'checked' : '' ?>>
                                <label class="form-check-label" for="channel_telegram_enabled">Enable Telegram</label>
                            </div>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label">Telegram Bot Token</label>
                                <input class="form-control" name="telegram_bot_token" value="<?= e($settings['telegram_bot_token']) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Telegram Chat ID</label>
                                <input class="form-control" name="telegram_chat_id" value="<?= e($settings['telegram_chat_id']) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label">Telegram Thread ID (optional)</label>
                                <input class="form-control" name="telegram_thread_id" value="<?= e($settings['telegram_thread_id']) ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($activeSection === 'general'): ?>
        <div class="card-header bg-surface-2 border-soft">Cache TTL (detik)</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-2">
                    <label class="form-label">Status List</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_status_list" value="<?= e($settings['cache_ttl_status_list']) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Status Single</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_status_single" value="<?= e($settings['cache_ttl_status_single']) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">History 24h</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_history_24h" value="<?= e($settings['cache_ttl_history_24h']) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">History 7d</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_history_7d" value="<?= e($settings['cache_ttl_history_7d']) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">History 30d</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_history_30d" value="<?= e($settings['cache_ttl_history_30d']) ?>">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Alert Logs</label>
                    <input class="form-control" type="number" min="1" name="cache_ttl_alert_logs" value="<?= e($settings['cache_ttl_alert_logs']) ?>">
                </div>
            </div>
            <div class="settings-actions d-flex gap-2 flex-wrap">
                <button class="btn btn-info" type="submit" data-submit-loading data-loading-text="Saving...">Save Settings</button>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($activeSection === 'security'): ?>
        <div class="card-header bg-surface-2 border-soft">Session Security</div>
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Idle Timeout (minutes)</label>
                    <input class="form-control" type="number" min="5" name="session_idle_timeout_minutes" value="<?= e($settings['session_idle_timeout_minutes']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Absolute Timeout (minutes)</label>
                    <input class="form-control" type="number" min="15" name="session_absolute_timeout_minutes" value="<?= e($settings['session_absolute_timeout_minutes']) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label d-block">Notes</label>
                    <div class="text-secondary small mt-2">Idle timeout berlaku jika tidak ada aktivitas. Absolute timeout berlaku sejak login.</div>
                </div>
            </div>
        </div>

        <div class="card-header bg-surface-2 border-soft">Data Retention</div>
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Core Retention (days)</label>
                    <select class="form-select" name="retention_days">
                        <?php foreach ([2, 7, 15, 30, 60, 90] as $d): ?>
                            <option value="<?= $d ?>" <?= (int) $settings['retention_days'] === $d ? 'selected' : '' ?>><?= $d ?> days</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Disk Retention (days)</label>
                    <select class="form-select" name="disk_retention_days">
                        <?php foreach ([7, 15, 30, 60, 90, 180, 365] as $d): ?>
                            <option value="<?= $d ?>" <?= (int) ($settings['disk_retention_days'] ?? '90') === $d ? 'selected' : '' ?>><?= $d ?> days</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6 settings-actions d-flex gap-2 flex-wrap">
                    <button class="btn btn-info" type="submit" data-submit-loading data-loading-text="Saving...">Save Settings</button>
                    <button class="btn btn-outline-warning" type="submit" name="action" value="run_retention" data-submit-loading data-loading-text="Running...">Run Core Retention</button>
                    <button class="btn btn-outline-warning" type="submit" name="action" value="run_disk_retention" data-submit-loading data-loading-text="Running...">Run Disk Retention</button>
                </div>
            </div>
            <div class="small text-secondary mt-2">
                Core retention cleans metrics/alerts/login/audit. Disk retention cleans disk health metrics and disk history.
            </div>
        </div>
        <?php endif; ?>

        <?php if ($activeSection === 'notifications'): ?>
        <div class="card-header bg-surface-2 border-soft">Test Notification</div>
        <div class="card-body">
            <div class="settings-actions d-flex gap-2 flex-wrap mt-0">
                <button class="btn btn-info" type="submit" data-submit-loading data-loading-text="Saving...">Save Settings</button>
                <button class="btn btn-outline-success" type="submit" name="action" value="test_email" data-submit-loading data-loading-text="Sending test...">Test Email</button>
                <button class="btn btn-outline-primary" type="submit" name="action" value="test_telegram" data-submit-loading data-loading-text="Sending test...">Test Telegram</button>
            </div>
        </div>
        <?php endif; ?>
    </form>
    <?php endif; ?>

    <?php if ($activeSection === 'users'): ?>
    <section class="card card-neon" data-ui-section>
        <div class="card-header bg-surface-2 border-soft d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span>User Management</span>
            <span class="text-secondary small">Manage admin/viewer accounts</span>
        </div>
        <div class="card-body">
            <form method="post" class="row g-3 align-items-end mb-4 border-soft rounded-3 p-3">
                <?= csrf_input() ?>
                <input type="hidden" name="action" value="user_create">
                <input type="hidden" name="section" value="users">
                <div class="col-12">
                    <h2 class="h6 mb-0">Create New User</h2>
                    <p class="text-secondary small mb-0">Gunakan role <code>viewer</code> untuk akses baca, <code>admin</code> untuk manajemen penuh.</p>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Username</label>
                    <input class="form-control" name="username" required maxlength="50" pattern="[a-zA-Z0-9_.-]{3,50}">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Password</label>
                    <input class="form-control" type="password" name="password" required minlength="8">
                </div>
                <div class="col-md-2">
                    <label class="form-label">Role</label>
                    <select class="form-select" name="role">
                        <option value="viewer">viewer</option>
                        <option value="admin">admin</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-info w-100" type="submit" data-submit-loading data-loading-text="Creating...">Add User</button>
                </div>
            </form>

            <div class="table-responsive table-shell">
                <table class="table servmon-table mb-0">
                    <thead>
                    <tr>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Last Login</th>
                        <th>Created At</th>
                        <th class="text-end">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($users)): ?>
                        <tr><td colspan="5" class="table-empty">No users found.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($users as $userRow): ?>
                        <?php $isSelf = (int) ($userRow['id'] ?? 0) === (int) ($currentUser['id'] ?? 0); ?>
                        <?php $isLastAdmin = (string) ($userRow['role'] ?? '') === 'admin' && $adminCount <= 1; ?>
                        <tr>
                            <td><?= e((string) $userRow['username']) ?><?= $isSelf ? ' <span class="text-secondary small">(you)</span>' : '' ?></td>
                            <td><span class="badge text-bg-secondary text-uppercase"><?= e((string) $userRow['role']) ?></span></td>
                            <td><?= e((string) ($userRow['last_login'] ?? '-')) ?></td>
                            <td><?= e((string) ($userRow['created_at'] ?? '-')) ?></td>
                            <td class="text-end">
                                <div class="d-inline-flex flex-column gap-2 align-items-end">
                                    <form method="post" class="d-inline-flex flex-wrap gap-2 align-items-center justify-content-end">
                                        <?= csrf_input() ?>
                                        <input type="hidden" name="action" value="user_update">
                                        <input type="hidden" name="section" value="users">
                                        <input type="hidden" name="user_id" value="<?= e((string) $userRow['id']) ?>">
                                        <select class="form-select form-select-sm" name="role" style="max-width: 130px;">
                                            <option value="viewer" <?= (string) $userRow['role'] === 'viewer' ? 'selected' : '' ?>>viewer</option>
                                            <option value="admin" <?= (string) $userRow['role'] === 'admin' ? 'selected' : '' ?>>admin</option>
                                        </select>
                                        <input class="form-control form-control-sm" type="password" name="new_password" placeholder="new password (optional)" style="max-width: 220px; display:inline-block;">
                                        <button class="btn btn-sm btn-outline-info" type="submit" data-submit-loading data-loading-text="Saving...">Save</button>
                                    </form>
                                    <form method="post" class="d-inline">
                                        <?= csrf_input() ?>
                                        <input type="hidden" name="action" value="user_delete">
                                        <input type="hidden" name="section" value="users">
                                        <input type="hidden" name="user_id" value="<?= e((string) $userRow['id']) ?>">
                                        <button class="btn btn-sm btn-outline-danger" type="submit" data-confirm="Delete user <?= e((string) $userRow['username']) ?>?" data-submit-loading data-loading-text="Deleting..." <?= ($isSelf || $isLastAdmin) ? 'disabled' : '' ?>>Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <?php if ($activeSection === 'ops'): ?>
    <section class="card card-neon" data-ui-section>
        <div class="card-header bg-surface-2 border-soft">Worker Health</div>
        <div class="card-body">
            <div class="table-responsive table-shell">
                <table class="table servmon-table mb-0">
                    <thead>
                    <tr>
                        <th>Worker</th>
                        <th>Health</th>
                        <th>Last Success</th>
                        <th>Last Error</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($workerStatuses as $workerName => $workerStatus): ?>
                        <?php
                        $health = (string) ($workerStatus['health'] ?? 'unknown');
                        $badgeClass = match ($health) {
                            'ok' => 'text-bg-success',
                            'error' => 'text-bg-danger',
                            'late' => 'text-bg-warning',
                            default => 'text-bg-secondary',
                        };
                        ?>
                        <tr>
                            <td><code><?= e($workerName) ?></code></td>
                            <td><span class="badge <?= e($badgeClass) ?> text-uppercase"><?= e($health) ?></span></td>
                            <td><?= e((string) ($workerStatus['last_success_at'] ?? 'never')) ?></td>
                            <td><?= e((string) ($workerStatus['last_error'] ?? '-')) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
    <section class="card card-neon" data-ui-section>
        <div class="card-header bg-surface-2 border-soft">Operations Runbook</div>
        <div class="card-body">
            <h2 class="h6 mb-2">Recommended Cron</h2>
            <pre class="code-block rounded p-3 mb-0"><code><?= e(implode(PHP_EOL, $recommendedCron)) ?></code></pre>
        </div>
    </section>
    <?php endif; ?>
</main>
<script src="<?= e(asset_url('assets/js/forms.js')) ?>"></script>
<?php require_once __DIR__ . '/../includes/layout/footer.php'; ?>
